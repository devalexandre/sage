import sqlite3
from pathlib import Path

DB_PATH = Path.home() / ".sage" / "history.db"


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS entries (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            text      TEXT    NOT NULL,
            kind      TEXT    NOT NULL DEFAULT 'memory',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


def insert_entry(text: str, kind: str = "memory") -> int:
    conn = _connect()
    cursor = conn.execute(
        "INSERT INTO entries (text, kind) VALUES (?, ?)", (text, kind)
    )
    conn.commit()
    entry_id = cursor.lastrowid
    conn.close()
    return entry_id


def recent_entries(limit: int = 20) -> list[dict]:
    conn = _connect()
    rows = conn.execute(
        "SELECT id, text, kind, created_at FROM entries ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [{"id": r[0], "text": r[1], "kind": r[2], "created_at": r[3]} for r in rows]
