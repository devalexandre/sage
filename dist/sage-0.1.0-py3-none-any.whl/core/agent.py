import os
from pathlib import Path

from agno.agent import Agent
from agno.db.sqlite import SqliteDb
from agno.learn.machine import LearningMachine
from agno.models.openai import OpenAIChat

from core import config as cfg

DB_PATH = Path.home() / ".sage" / "sage.db"
USER_ID = "sage_user"

_agent: Agent | None = None


def reset_agent() -> None:
    """Discard the cached agent so it is rebuilt with the latest config."""
    global _agent
    _agent = None


def _get_agent() -> Agent:
    global _agent
    if _agent is None:
        conf = cfg.load()

        # API key: config file takes priority over .env / environment
        api_key = conf.get("openai_api_key", "").strip()
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key

        model_id = conf.get("openai_model", "gpt-4o-mini")

        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        db = SqliteDb(db_file=str(DB_PATH))
        _agent = Agent(
            model=OpenAIChat(id=model_id),
            db=db,
            learning=LearningMachine(
                db=db,
                user_memory=True,
                learned_knowledge=True,
            ),
            enable_agentic_memory=True,
            add_learnings_to_context=True,
            description=(
                "You are Sage, a personal knowledge assistant. "
                "You store facts shared by the user and answer questions based on what was memorized."
            ),
            instructions=[
                "When asked to store or remember something, save the fact and confirm with 'Saved.'",
                "When answering questions, search your memory for relevant information.",
                "If no relevant information is found in memory, reply: 'I couldn't find that in my knowledge.'",
                "Be concise. Short, direct answers only.",
            ],
        )
    return _agent


def store_fact(text: str) -> str:
    agent = _get_agent()
    response = agent.run(
        f"Remember this fact: {text}",
        user_id=USER_ID,
        stream=False,
    )
    return response.get_content_as_string() or "Saved."


def query_knowledge(question: str) -> str:
    agent = _get_agent()
    response = agent.run(
        question,
        user_id=USER_ID,
        stream=False,
    )
    return response.get_content_as_string() or "I couldn't find that in my knowledge."
