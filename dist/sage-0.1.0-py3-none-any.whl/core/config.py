import json
from pathlib import Path

CONFIG_PATH = Path.home() / ".sage" / "config.json"

_DEFAULTS: dict = {
    "openai_api_key": "",
    "openai_model": "gpt-4o-mini",
}


def load() -> dict:
    if CONFIG_PATH.exists():
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            return {**_DEFAULTS, **data}
        except Exception:
            pass
    return dict(_DEFAULTS)


def save(data: dict) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
