import platform
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QKeyEvent
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from core import config as cfg

_OS = platform.system()  # "Linux", "Darwin", "Windows"

OPENAI_MODELS = [
    "gpt-4o-mini",
    "gpt-4o",
    "gpt-4-turbo",
    "gpt-3.5-turbo",
    "o1-mini",
    "o1",
]


# ── autostart helpers ─────────────────────────────────────────────────────────

def _resolve_exec() -> str:
    sage_bin = Path(sys.executable).parent / ("sage.exe" if _OS == "Windows" else "sage")
    if sage_bin.exists():
        return str(sage_bin)
    app_py = Path(__file__).parent.parent / "app.py"
    return f"{sys.executable} {app_py}"


# ── Linux (XDG autostart) ─────────────────────────────────────────────────────
_DESKTOP_DIR = Path.home() / ".config" / "autostart"
_DESKTOP_FILE = _DESKTOP_DIR / "sage.desktop"
_DESKTOP_TEMPLATE = """\
[Desktop Entry]
Type=Application
Name=Sage
Comment=Personal knowledge widget
Exec={exec_path}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
"""

def _linux_enabled() -> bool:
    return _DESKTOP_FILE.exists()

def _linux_set(enabled: bool) -> None:
    if enabled:
        _DESKTOP_DIR.mkdir(parents=True, exist_ok=True)
        _DESKTOP_FILE.write_text(_DESKTOP_TEMPLATE.format(exec_path=_resolve_exec()))
    else:
        _DESKTOP_FILE.unlink(missing_ok=True)


# ── Windows (registry Run key) ────────────────────────────────────────────────
_WIN_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
_WIN_APP_NAME = "Sage"

def _windows_enabled() -> bool:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _WIN_REG_KEY) as key:
            winreg.QueryValueEx(key, _WIN_APP_NAME)
        return True
    except Exception:
        return False

def _windows_set(enabled: bool) -> None:
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, _WIN_REG_KEY, 0, winreg.KEY_SET_VALUE
        ) as key:
            if enabled:
                winreg.SetValueEx(key, _WIN_APP_NAME, 0, winreg.REG_SZ, _resolve_exec())
            else:
                winreg.DeleteValue(key, _WIN_APP_NAME)
    except Exception:
        pass


# ── macOS (launchd plist) ─────────────────────────────────────────────────────
_PLIST_DIR = Path.home() / "Library" / "LaunchAgents"
_PLIST_FILE = _PLIST_DIR / "com.sage.app.plist"
_PLIST_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.sage.app</string>
  <key>ProgramArguments</key>
  <array><string>{exec_path}</string></array>
  <key>RunAtLoad</key><true/>
</dict>
</plist>
"""

def _macos_enabled() -> bool:
    return _PLIST_FILE.exists()

def _macos_set(enabled: bool) -> None:
    if enabled:
        _PLIST_DIR.mkdir(parents=True, exist_ok=True)
        _PLIST_FILE.write_text(_PLIST_TEMPLATE.format(exec_path=_resolve_exec()))
    else:
        _PLIST_FILE.unlink(missing_ok=True)


# ── public autostart API ──────────────────────────────────────────────────────
def _autostart_enabled() -> bool:
    if _OS == "Windows":
        return _windows_enabled()
    if _OS == "Darwin":
        return _macos_enabled()
    return _linux_enabled()

def _set_autostart(enabled: bool) -> None:
    if _OS == "Windows":
        _windows_set(enabled)
    elif _OS == "Darwin":
        _macos_set(enabled)
    else:
        _linux_set(enabled)


# ── palette ───────────────────────────────────────────────────────────────────
_BG = "#1E1E2E"
_SURFACE = "#313244"
_BORDER = "#45475A"
_TEXT = "#CDD6F4"
_MUTED = "#6C7086"
_ACCENT = "#7C3AED"
_GREEN = "#A6E3A1"


# ── settings window ───────────────────────────────────────────────────────────
class SageSettings(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedWidth(340)
        self._build_ui()

    # ── layout ────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        card = QFrame()
        card.setObjectName("card")
        card.setStyleSheet(f"""
            QFrame#card {{
                background: {_BG};
                border: 1px solid {_BORDER};
                border-radius: 14px;
            }}
        """)
        outer.addWidget(card)

        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 16)
        layout.setSpacing(10)

        # ── title row ─────────────────────────────────────────────────────────
        title_row = QHBoxLayout()
        title = QLabel("Settings")
        title.setFont(QFont("Inter", 13, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {_TEXT};")
        title_row.addWidget(title)
        title_row.addStretch()
        close_btn = QPushButton("×")
        close_btn.setFixedSize(22, 22)
        close_btn.setStyleSheet(f"""
            QPushButton {{ color: {_MUTED}; background: transparent; border: none; font-size: 16px; }}
            QPushButton:hover {{ color: {_TEXT}; }}
        """)
        close_btn.clicked.connect(self.hide)
        title_row.addWidget(close_btn)
        layout.addLayout(title_row)

        layout.addWidget(_separator())

        # ── General section ───────────────────────────────────────────────────
        layout.addWidget(_section_label("General"))

        self._startup_cb = QCheckBox("Start with system")
        self._startup_cb.setChecked(_autostart_enabled())
        self._startup_cb.setStyleSheet(_checkbox_style())
        self._startup_cb.toggled.connect(_set_autostart)
        layout.addWidget(self._startup_cb)

        layout.addWidget(_separator())

        # ── OpenAI section ────────────────────────────────────────────────────
        layout.addWidget(_section_label("OpenAI"))

        # API Key label
        layout.addWidget(_field_label("API Key"))

        # API Key input row
        key_row = QHBoxLayout()
        self._key_input = QLineEdit()
        self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self._key_input.setPlaceholderText("sk-…")
        self._key_input.setStyleSheet(_input_style())
        key_row.addWidget(self._key_input)

        self._eye_btn = QPushButton("👁")
        self._eye_btn.setFixedSize(34, 34)
        self._eye_btn.setCheckable(True)
        self._eye_btn.setStyleSheet(f"""
            QPushButton {{
                background: {_SURFACE}; border: 1px solid {_BORDER};
                border-radius: 8px; font-size: 14px;
            }}
            QPushButton:checked {{ border-color: {_ACCENT}; }}
            QPushButton:hover {{ border-color: {_TEXT}; }}
        """)
        self._eye_btn.toggled.connect(self._toggle_key_visibility)
        key_row.addWidget(self._eye_btn)
        layout.addLayout(key_row)

        # Model label + combo
        layout.addWidget(_field_label("Model"))

        self._model_combo = QComboBox()
        self._model_combo.addItems(OPENAI_MODELS)
        self._model_combo.setStyleSheet(f"""
            QComboBox {{
                background: {_SURFACE};
                color: {_TEXT};
                border: 1px solid {_BORDER};
                border-radius: 8px;
                padding: 6px 12px;
                font-size: 13px;
            }}
            QComboBox:focus {{ border-color: {_ACCENT}; }}
            QComboBox::drop-down {{ border: none; width: 24px; }}
            QComboBox::down-arrow {{ width: 10px; height: 10px; }}
            QComboBox QAbstractItemView {{
                background: {_SURFACE};
                color: {_TEXT};
                border: 1px solid {_BORDER};
                selection-background-color: {_ACCENT};
            }}
        """)
        layout.addWidget(self._model_combo)

        # Save button
        self._save_btn = QPushButton("Save")
        self._save_btn.setFixedHeight(36)
        self._save_btn.setStyleSheet(f"""
            QPushButton {{
                background: {_ACCENT}; color: white;
                border-radius: 8px; font-size: 13px; font-weight: bold;
            }}
            QPushButton:hover {{ background: #6D28D9; }}
            QPushButton:pressed {{ background: #5B21B6; }}
        """)
        self._save_btn.clicked.connect(self._save_openai)
        layout.addWidget(self._save_btn)

        # Status label (feedback after save)
        self._save_status = QLabel("")
        self._save_status.setStyleSheet(f"color: {_GREEN}; font-size: 11px;")
        self._save_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._save_status)

    # ── actions ───────────────────────────────────────────────────────────────
    def _toggle_key_visibility(self, visible: bool) -> None:
        mode = QLineEdit.EchoMode.Normal if visible else QLineEdit.EchoMode.Password
        self._key_input.setEchoMode(mode)

    def _save_openai(self) -> None:
        conf = cfg.load()
        conf["openai_api_key"] = self._key_input.text().strip()
        conf["openai_model"] = self._model_combo.currentText()
        cfg.save(conf)

        # Reset the agent singleton so it picks up the new key + model
        from core.agent import reset_agent
        reset_agent()

        self._save_status.setText("Saved.")
        from PySide6.QtCore import QTimer
        QTimer.singleShot(2000, lambda: self._save_status.setText(""))

    def _load_openai_fields(self) -> None:
        conf = cfg.load()
        self._key_input.setText(conf.get("openai_api_key", ""))
        model = conf.get("openai_model", OPENAI_MODELS[0])
        idx = self._model_combo.findText(model)
        self._model_combo.setCurrentIndex(idx if idx >= 0 else 0)

    # ── show / hide ───────────────────────────────────────────────────────────
    def toggle(self) -> None:
        if self.isVisible():
            self.hide()
        else:
            self._startup_cb.setChecked(_autostart_enabled())
            self._load_openai_fields()
            self._save_status.setText("")
            self._position()
            self.show()
            self.raise_()
            self.activateWindow()

    def _position(self) -> None:
        screen = QApplication.primaryScreen().availableGeometry()
        self.adjustSize()
        x = screen.right() - self.width() - 20
        y = screen.bottom() - self.height() - 60
        self.move(x, y)

    # ── keyboard ──────────────────────────────────────────────────────────────
    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(event)


# ── widget helpers ────────────────────────────────────────────────────────────
def _separator() -> QFrame:
    sep = QFrame()
    sep.setFrameShape(QFrame.Shape.HLine)
    sep.setStyleSheet(f"color: {_BORDER};")
    return sep

def _section_label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color: {_MUTED}; font-size: 11px; font-weight: bold;")
    return lbl

def _field_label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color: {_TEXT}; font-size: 12px;")
    return lbl

def _input_style() -> str:
    return f"""
        QLineEdit {{
            background: {_SURFACE};
            color: {_TEXT};
            border: 1px solid {_BORDER};
            border-radius: 8px;
            padding: 7px 12px;
            font-size: 13px;
        }}
        QLineEdit:focus {{ border-color: {_ACCENT}; }}
    """

def _checkbox_style() -> str:
    return f"""
        QCheckBox {{
            color: {_TEXT};
            font-size: 13px;
            spacing: 8px;
        }}
        QCheckBox::indicator {{
            width: 16px; height: 16px;
            border: 1px solid {_BORDER};
            border-radius: 4px;
            background: {_SURFACE};
        }}
        QCheckBox::indicator:checked {{
            background: {_ACCENT};
            border-color: {_ACCENT};
        }}
    """
