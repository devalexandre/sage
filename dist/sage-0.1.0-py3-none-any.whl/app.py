import sys
from pathlib import Path

from dotenv import load_dotenv
from PySide6.QtWidgets import QApplication, QMessageBox

# Load .env from project root (fallback to home)
load_dotenv(Path(__file__).parent / ".env")
load_dotenv(Path.home() / ".sage" / ".env")


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("Sage")
    app.setQuitOnLastWindowClosed(False)

    from PySide6.QtWidgets import QSystemTrayIcon

    if not QSystemTrayIcon.isSystemTrayAvailable():
        QMessageBox.critical(
            None,
            "Sage",
            "System tray is not available in this environment.",
        )
        sys.exit(1)

    from ui.tray import SageTray

    tray = SageTray()
    tray.show()
    tray.showMessage("Sage", "Ready. Click the icon to open.", tray.icon(), 2000)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
